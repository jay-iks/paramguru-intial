import React, { useRef, useEffect, useState } from "react";

import SwiperCore from "swiper";
import { Pagination, Scrollbar } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper-bundle.css"; // Import Swiper styles
import SliderCard from "./SliderCard";
// import './styles.css'; // Import your custom styles if any

// Install Swiper modules
SwiperCore.use([Scrollbar]);

const VerticalSwiper = () => {
  
  const [activeIndex, setActiveIndex] = useState(0); // State to keep track of active slide index
  const swiperRef = useRef(null);
  
  const slides = [
    {
      id: 1,
      image: "Images/DetailPage/gurudevjpg.mp4",
      isVideo: true,
      title: "A Gentle Heart",
      subtitle:
        "It is said that a mother plays the role of a Guru when the child is small and..",
    },

    {
      id: 3,
      image: "Images/SliderImages/3 (1).mp4",
      isVideo: true,
      title: "A Force that EMPOWERS…",
      subtitle: "In December 2022, Param Gurudev was at Palitana.... ",
    },
    {
      id: 4,
      image: "Images/DetailPage/Ram-Ram-Jai.mp4",
      isVideo: true,
      title: "Ram Laxman",
      subtitle: "In December 2022, Param Gurudev was at Palitana.... ",
    },
  ];

  return (



    
    <div>
      <Swiper
        direction="vertical"
        slidesPerView="auto"
        loop={true}
        scrollbar={{
          el: ".swiper-scrollbar",
          draggable: true,
        }}
        modules={[Scrollbar]}
        className=" w-screen h-screen  lg:w-3/4  lg:h-[70vh] lg:rounded-lg"
      >
        {slides.map((slide) => (
          <SwiperSlide key={slide.id}>
            <SliderCard
            
              key={slide.id}
              mediaSrc={slide.image}
              isVideo={slide.isVideo}
              title={slide.title}
              subtitle={slide.subtitle}
            />
          </SwiperSlide>
        ))}
       
      </Swiper>
    </div>
  );
};

export default VerticalSwiper;
